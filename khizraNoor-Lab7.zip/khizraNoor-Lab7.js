// let heading =document.getElementById("head");
// console.log(heading);
// let headings = document.getElementsByClassName("num");
// console.dir(headings);
// console.log(headings);
// let parahs = document.getElementsByTagName("p");
// console.dir(parahs);
// let fruits = document.getElementsById("fruits");
// console.log(fruits);

// Task 1
let head = document.getElementById("heading");
let name = " Anna ";  
let regNo = " 1111";  
head.innerText += name + regNo;

// Task 2
let divs = document.querySelectorAll(".Container");

let texts = ["Div One", "Div Two", "Div Three"];

for (let i = 0; i < 3; i++) {
    divs[i].innerText = texts[i];
}


